var counter = 0;
var unitPrice = 50;
var price = 0;
var  Shipping =0;
var Tax = 0;

if(counter <= 0){
    counter=0;
    price = 0;
    document.getElementById("counter").innerHTML = counter;
    document.getElementById("price").innerHTML = price;
    Shipping  = 0;
    
}

function increment() {
    counter++;
    Tax +=1;
    price = counter * unitPrice;
    document.getElementById("counter").innerHTML = counter;
    document.getElementById("price").innerHTML = price;

    if(counter > 0){
        Shipping=10;
    }
}


function decrement(){
    if (counter > 0) {
        counter--;
        Tax -=1;
        price = counter * unitPrice;
        document.getElementById("counter").innerHTML = counter;
        document.getElementById("price").innerHTML = price;
    
        if(counter <= 0){
            Shipping=0;
        }

    }
}

function addprice(){

    document.getElementById("Subtotal").innerHTML=price;
    document.getElementById("shipping").innerHTML=Shipping;
    document.getElementById("totalprice").innerHTML=price+Tax+Shipping;
    document.getElementById("tax").innerHTML=Tax;

    

}