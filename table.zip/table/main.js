

function addstudent(){


    var st_name=document.getElementById("st_name").value
    var st_father_name=document.getElementById("st_father_name").value
    var st_course=document.getElementById("st_course").value


    if(st_name=="" || st_course=="" || st_father_name==""){
        alert("Please fill all fields")
    }else{
    document.getElementById("student_list").style.display = ""
    
    document.getElementById("name").innerHTML=st_name
    document.getElementById("father").innerHTML=st_father_name
    document.getElementById("course").innerHTML=st_course

    document.getElementById("st_name").value=""
    document.getElementById("st_father_name").value=""
    document.getElementById("st_course").value=""

    document.getElementById("action").innerHTML = "Add Student"
    
 
    }

}

function update_st(){

    document.getElementById("action").innerHTML = "Update Student"

    var new_st_name=document.getElementById("name").innerHTML
    var new_st_father_name=document.getElementById("father").innerHTML
    var new_st_course=document.getElementById("course").innerHTML

    document.getElementById("st_name").value=new_st_name
    document.getElementById("st_father_name").value=new_st_father_name
    document.getElementById("st_course").value=new_st_course


}