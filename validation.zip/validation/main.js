

function validatePassword(){

    var name=document.getElementById("name").value;
    var nameRegex = /^[a-zA-Z0-9\s]+$/;

    if(nameRegex.test(name)){
        document.getElementById("result").innerHTML = "Name is valid";
    }else{
        document.getElementById("result").innerHTML = "Name must only contain alphabetic characters and spaces.";
    }


    /*
    var password =document.getElementById("password").value;
    var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;

    if(passwordRegex.test(password)){
        document.getElementById("result").innerHTML = "Password strong";
        
    }else{
        
        document.getElementById("result").innerHTML = "Password must contain at least 6 characters, including at least one uppercase letter, one lowercase letter, one number, and one special character.";
        
    }
        */
}